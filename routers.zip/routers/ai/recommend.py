from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from datetime import datetime
import requests
from config import KAKAO_API_KEY, WEATHER_API_KEY, OPENAI_API_KEY

router = APIRouter()

class LocationInput(BaseModel):
    latitude: float
    longitude: float

def call_gpt_recommendation(prompt: str) -> str:
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    body = {
        "model": "gpt-3.5-turbo",
        "messages": [{"role": "user", "content": prompt}]
    }
    response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=body)
    if response.status_code != 200:
        raise Exception(f"GPT 호출 실패: {response.status_code}")
    return response.json()["choices"][0]["message"]["content"]

def get_address_from_kakao(lat: float, lon: float) -> str:
    headers = {"Authorization": f"KakaoAK {KAKAO_API_KEY}"}
    url = f"https://dapi.kakao.com/v2/local/geo/coord2address.json?x={lon}&y={lat}"
    response = requests.get(url, headers=headers)
    data = response.json()
    if "documents" in data and data["documents"]:
        return data["documents"][0]["address"]["address_name"]
    return "주소 정보 없음"

def get_weather(lat: float, lon: float) -> (str, float):
    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={WEATHER_API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()
    weather = data["weather"][0]["description"]
    temp = data["main"]["temp"]
    return weather, temp

def get_season_and_time() -> (str, str):
    now = datetime.now(pytz.timezone("Asia/Seoul"))
    hour = now.hour
    month = now.month

    if month in [3, 4, 5]:
        season = "봄"
    elif month in [6, 7, 8]:
        season = "여름"
    elif month in [9, 10, 11]:
        season = "가을"
    else:
        season = "겨울"

    if hour < 5:
        time_of_day = "밤"
    elif hour < 12:
        time_of_day = "아침"
    elif hour < 17:
        time_of_day = "낮"
    elif hour < 20:
        time_of_day = "저녁"
    else:
        time_of_day = "밤"

    return season, time_of_day

@router.post("/ai/recommend_point_full")
def recommend_point_full(input: LocationInput):
    try:
        lat, lon = input.latitude, input.longitude
        address = get_address_from_kakao(lat, lon)
        weather, temp = get_weather(lat, lon)
        season, time_of_day = get_season_and_time()

        prompt = f"{season} {time_of_day}에 {address}({weather}, {temp:.1f}°C)에서 배스낚시 포인트를 추천해줘. 포인트 이름, 채비, 방향 등을 알려줘."
        gpt_result = call_gpt_recommendation(prompt)

        return {
            "location": address,
            "weather": weather,
            "temperature": temp,
            "season": season,
            "time": time_of_day,
            "recommendation": gpt_result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
